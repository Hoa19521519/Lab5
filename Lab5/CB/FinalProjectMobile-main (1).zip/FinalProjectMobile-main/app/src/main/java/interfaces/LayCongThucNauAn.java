package interfaces;

public interface LayCongThucNauAn {
    void batDau();
    void ketThuc(String data);
    void biLoi();
}
